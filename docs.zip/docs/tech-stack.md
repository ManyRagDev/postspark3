# Stack Tecnológica e Padrões (TECH_STACK)

## Contexto de Servidor Externo
* **Screenshot Service:** App independente em Playwright hospedado no Railway. Usado para não sobrecarregar nossa root.

## Backend Central
* **Linguagem:** TypeScript (Node.js v20+)
* **Framework:** Express customizado + tRPC API
* **Banco de Dados:** PostgreSQL (migrações geridas via Drizzle ORM)
* **Inteligência Artificial (LLMs):** Gemini (via api oficial) com fallback nativo de Groq API (`llama-3.3-70b-versatile`). As requisições são extraídas em schema JSON rigoroso.
* **Storage e Pagamentos:** Integração Manus OAuth / Amazon S3 Uploads (ou genéricos) e Webhooks do Stripe.

## Frontend
* **Core:** React 18+ com Vite
* **Estilização:** TailwindCSS v4
* **Motion & Interação:** Framer Motion predominante
* **Manejo de Estado Remoto:** `react-query` gerido pelo tRPC provider

## Testes (Obrigatório)
* **Comando para rodar testes:** `pnpm test` (executa `vitest run`)
* **Framework de testes:** Vitest

## Padrões de Código
* **Commits:** Usar Conventional Commits (`feat:`, `fix:`, `chore:`, `refactor:`)
* **Idioma do código:** Inglês (funções, variáveis, etc).
* **Idioma da documentação:** Português (para contexto rápido e specs).
* Evite bibliotecas UI complexas ou "shadcn-like" redundantes. Prefira nativo Tailwind 4 se a biblioteca adicionar JavaScript extra desnecessário. Mantenha as funções puras.
