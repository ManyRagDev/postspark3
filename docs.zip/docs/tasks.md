# Tarefas e Progresso do Projeto (PROGRESS / TASKS)

> Este é o arquivo de atualização constante. Ele serve para o Conductor saber onde parou.

## Concluído Recentemente
- [x] Extração de Screenshots delegada ao Railway (Microsserviço Playwright).
- [x] Adicionar endpoint REST validador `/api/extract` extraindo Buffer e avaliando Payload KB.
- [x] LLM Fallback: Falhas do Gemini direcionam perfeitamente para Llama-3.3 via Groq retirando suporte multimodal on-the-fly (`server/_core/llm.ts`).
- [x] Otimização Touch mobile (alvos mínimos de `44px` configurados, Toolbar fixada).
- [x] Banco de Dados Schema Drizzle + JSON para textElements pronto.
- [x] ThemeEngine & ChameleonProtocol com análise visual instalados.
- [x] Análise de sentimento e Modo Diretor no Workbench (29 testes passando)

## Trabalhando Agora
- [ ] Inline Toolbar para edição de texto/imagem no painel `AdvancedTextCanvas`.
- [ ] Focus Lift (navegação avançada por teclado).

## Próximos Passos (Débitos Restantes)
- [ ] Separar definitivamente estrutura de post: headline | corpo | CTA | hashtags para melhor componentização do preview.
- [ ] Criar seletor de "Layouts pré-prontos" visuais.
- [ ] Detecção de estilo visual primário da URL na extração de contexto (`neubrutalist`, `minimalista`, `neon`, etc.).
- [ ] Reorganizar ergonomia dos botões nos cards (Gerar Imagem | Editar | Escolher Layout).

*Atualizado dinamicamente pelo Conductor no fechamento de cada ticket ou task substancial.*
