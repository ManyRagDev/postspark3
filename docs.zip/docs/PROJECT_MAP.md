# Mapa e Estrutura do Projeto

Para evitar varreduras de pastas extensivas, eis a árvore principal do projeto PostSpark 3 e as responsabilidades de cada domínio.

## Visão Macro

```
/client          -> Aplicação Frontend (React + Vite + Tailwind 4)
/server          -> Aplicação Backend (Node.js + Express + tRPC)
/shared          -> Contratos de tipos entre client/server
/docs            -> Toda a inteligência da metodologia de projeto, documentação e logs contextuais
/drizzle         -> Schemas do banco e migrações SQL geradas
```

## Explorando `/client/src`

* `components/views`: As páginas ou "estados" principais da aplicação (`TheVoid`, `HoloDeck`, `Workbench`).
* `components/ui`: Componentes reaproveitáveis de baixo-nível estilizados com Tailwind e possivelmente `class-variance-authority`.
* `hooks`: Utilitários customizados do React (ex: hooks do tRPC).
* `styles`: Root config de CSS global, embora a maioria seja utility-first no JSX.

## Explorando `/server`

* `_core`: Centro nervoso da infraestrutura do server. Contém `index.ts` (App e middlewares Express), `llm.ts` (Logics avançadas e wrappers do Gemini/Groq), `env.ts` e configurações OAuth.
* `routers`: Definições das procedures do tRPC (`post.ts`, `auth.ts`, etc).
* `*Service.ts` e `*Generator.ts`: Funções orquestradoras (ex: `screenshotService.ts` que se comunica com o serviço Railway externo).
* `db`: Configuração de cliente Drizzle e conector com o BD Postgres.

## Arquivos Especiais da Raiz
* `.env`: Credenciais vitais de banco e API, e tokens (Railway Screenshot URL, Groq API, Supabase).
* `package.json`: Gestão do monorepo (ou workspaces).
* `vite.config.ts` / `vitest.config.ts`: Ferramental do processo de build e testes.
