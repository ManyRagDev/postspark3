# Cérebro do Projeto (CONTEXT)

**Última Atualização:** Integração Railway e Robutez de Dados
Este arquivo dita a visão atual, regras de ouro e deltas de arquitetura em execução.

## Visão Geral
O PostSpark visa acelerar imensamente a criação de conteúdo social. O usuário entra com uma ideia ou uma URL, e a IA extrai a "Brand DNA" (cores, vibe, intenção) para gerar posts visualmente atraentes em múltiplos formatos (1:1, 5:6, 9:16). O fluxo divide-se em The Void (Input) -> HoloDeck (Variações 3D) -> Workbench (Edição Fina).

## Regras de Ouro
1. **Nativo Sobre Externo:** Não adicione bibliotecas pesadas se o TailwindCSS v4 ou CSS puro der conta do recado (ex: sliders, inputs estilizados).
2. **Separação de Preocupações de Serviços:** 
   - **Screenshot Service (Railway):** Microsserviço independente em Playwright. 
     - *Lógica Interna:* Utiliza um **Browser Pool** (reuso de instância Chromium) para performance em Linux/Railway, mas isola cada requisição em um `BrowserContext` único. 
     - *Sanitização:* Executa scripts automáticos para remover banners de cookies, modais de GDPR e widgets de chat antes da captura.
     - *Descoberta:* Possui lógica de `/discover` para mapear páginas internas (Sobre, Preços, Blog) baseada em prioridade de palavras-chave.
   - **LLMs abstratos:** `server/_core/llm.ts` consolida a chamada, usando nativamente Gemini, e com um fallback inteligente validado em `llama-3.3-70b-versatile` via Groq em caso restrições (eliminou multimodal parsing onde não suportado).
3. **Consistência de Tipos:** A camada `shared` com Zod e tRPC é a verdade absoluta na comunicação entre Client e Server.
4. **Resiliência Mobile:** O app foi recentemente refatorado para mobile-first. Tudo de interatividade pesada no mobile deve prever Sheet Modals bottom-up e Toolbars Fixas para facilitar toque, garantindo alvos mínimos de 44px.

## Arquitetura: Como os módulos se comunicam
- O input começa no client em `/client/src/components/views/TheVoid.tsx`.
- Comunica com o backend primariamente usando rotas tRPC para gerar variations (conteúdo LLM).
- Há rotas essenciais REST (ex: `/api/extract` e `/api/brand-dna` em `server/_core/index.ts`) que orquestram requisições pesadas (como o fetch de Screenshots no Railway).
- Backend processa dados, armazena estado em PostgreSQL usando schemas Drizzle `postspark`, previnindo prop drilling excessivo no frontend via salvamento e recarregamento constante entre estados.
